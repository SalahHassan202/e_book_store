const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const app = express();

app.use(cors());
app.use(express.json());

let books = [
  {
    id: 1,
    title: "React for Beginners",
    author: "John Doe",
    price: 20,
    image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 2,
    title: "Mastering JavaScript",
    author: "Jane Smith",
    price: 25,
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 3,
    title: "CSS in Depth",
    author: "Emily Johnson",
    price: 15,
    image: "https://images.unsplash.com/photo-1512820790803-83ca734da794",
    category: "Design",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 4,
    title: "HTML & CSS Design",
    author: "Michael Brown",
    price: 18,
    image: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2",
    category: "Design",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 5,
    title: "Node.js Essentials",
    author: "Linda Green",
    price: 22,
    image: "https://images.unsplash.com/photo-1516321497487-e288fb19713f",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 6,
    title: "Advanced React Patterns",
    author: "Chris Wilson",
    price: 30,
    image: "https://images.unsplash.com/photo-1517430816045-df4b7de11d1d",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 7,
    title: "JavaScript Algorithms",
    author: "Sarah Lee",
    price: 27,
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 8,
    title: "TypeScript in Practice",
    author: "David White",
    price: 24,
    image: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 9,
    title: "Web Performance Tips",
    author: "Anna Kim",
    price: 20,
    image: "https://images.unsplash.com/photo-1527689368864-3a821dbccc34",
    category: "Design",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 10,
    title: "Design Systems",
    author: "James Clark",
    price: 26,
    image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e",
    category: "Design",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 11,
    title: "Fullstack Development",
    author: "Alice Walker",
    price: 28,
    image: "https://images.unsplash.com/photo-1517430816045-df4b7de11d1d",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 12,
    title: "GraphQL Essentials",
    author: "Bob Martin",
    price: 23,
    image: "https://images.unsplash.com/photo-1516321497487-e288fb19713f",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 13,
    title: "Docker for Developers",
    author: "Chris Evans",
    price: 30,
    image: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 14,
    title: "Kubernetes in Action",
    author: "Diana Prince",
    price: 35,
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 15,
    title: "Microservices Patterns",
    author: "Ethan Hunt",
    price: 32,
    image: "https://images.unsplash.com/photo-1516321497487-e288fb19713f",
    category: "Architecture",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 16,
    title: "Clean Code",
    author: "Robert C. Martin",
    price: 29,
    image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 17,
    title: "Effective JavaScript",
    author: "David Herman",
    price: 21,
    image: "https://images.unsplash.com/photo-1517430816045-df4b7de11d1d",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 18,
    title: "Learning Python",
    author: "Mark Lutz",
    price: 26,
    image: "https://images.unsplash.com/photo-1516321497487-e288fb19713f",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 19,
    title: "Agile Project Management",
    author: "Mike Cohn",
    price: 24,
    image: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2",
    category: "Management",
    ratings: [],
    isFavorite: false,
  },
  {
    id: 20,
    title: "Refactoring",
    author: "Martin Fowler",
    price: 33,
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
    category: "Programming",
    ratings: [],
    isFavorite: false,
  },
];

let users = [];
let orders = [];

app.get("/books", (req, res) => {
  res.json(books);
});

app.post("/books", (req, res) => {
  const newBook = req.body;
  newBook.id = books.length ? books[books.length - 1].id + 1 : 1;
  newBook.ratings = [];
  newBook.isFavorite = false;
  books.push(newBook);
  res.status(201).json(newBook);
});

app.delete("/books/:id", (req, res) => {
  const bookId = parseInt(req.params.id);
  const index = books.findIndex((b) => b.id === bookId);
  if (index !== -1) {
    books.splice(index, 1);
    res.status(200).json({ message: "Book deleted successfully" });
  } else {
    res.status(404).json({ message: "Book not found" });
  }
});

app.put("/books/:id", (req, res) => {
  const bookId = parseInt(req.params.id);
  const index = books.findIndex((b) => b.id === bookId);
  if (index !== -1) {
    const updatedBook = {
      id: bookId,
      title: req.body.title,
      author: req.body.author,
      price: req.body.price,
      image: req.body.image || "",
      category: req.body.category,
      ratings: books[index].ratings,
      isFavorite: books[index].isFavorite,
    };
    books[index] = updatedBook;
    res.status(200).json(updatedBook);
  } else {
    res.status(404).json({ message: "Book not found" });
  }
});

app.post("/books/:id/ratings", (req, res) => {
  const bookId = parseInt(req.params.id);
  const index = books.findIndex((b) => b.id === bookId);
  if (index !== -1) {
    const newRating = {
      stars: req.body.stars,
      comment: req.body.comment,
      id: books[index].ratings.length + 1,
    };
    books[index].ratings.push(newRating);
    res.status(201).json(newRating);
  } else {
    res.status(404).json({ message: "Book not found" });
  }
});

app.patch("/books/:id/favorite", (req, res) => {
  const bookId = parseInt(req.params.id);
  const index = books.findIndex((b) => b.id === bookId);
  if (index !== -1) {
    books[index].isFavorite = req.body.isFavorite;
    res.status(200).json(books[index]);
  } else {
    res.status(404).json({ message: "Book not found" });
  }
});

app.post("/register", (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) {
    return res.status(400).json({ message: "All fields are required" });
  }
  if (users.find((u) => u.email === email)) {
    return res.status(400).json({ message: "Email already exists" });
  }
  const hashedPassword = bcrypt.hashSync(password, 8);
  const newUser = {
    id: users.length ? users[users.length - 1].id + 1 : 1,
    username,
    email,
    password: hashedPassword,
  };
  users.push(newUser);
  const token = jwt.sign({ id: newUser.id }, "secret_key", { expiresIn: "1h" });
  res.status(201).json({ token, user: { id: newUser.id, username, email } });
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find((u) => u.email === email);
  if (!user) {
    return res.status(400).json({ message: "User not found" });
  }
  const isValidPassword = bcrypt.compareSync(password, user.password);
  if (!isValidPassword) {
    return res.status(400).json({ message: "Invalid password" });
  }
  const token = jwt.sign({ id: user.id }, "secret_key", { expiresIn: "1h" });
  res
    .status(200)
    .json({ token, user: { id: user.id, username: user.username, email } });
});

app.post("/orders", (req, res) => {
  const { userId, items, name, email, address } = req.body;
  if (!userId || !items || !name || !email || !address) {
    return res.status(400).json({ message: "All fields are required" });
  }
  const total = items.reduce(
    (sum, item) => sum + item.book.price * item.quantity,
    0
  );
  const newOrder = {
    id: orders.length ? orders[orders.length - 1].id + 1 : 1,
    userId,
    items,
    name,
    email,
    address,
    total,
    date: new Date(),
  };
  orders.push(newOrder);
  res.status(201).json(newOrder);
});

app.get("/orders/:userId", (req, res) => {
  const userId = parseInt(req.params.userId);
  const userOrders = orders.filter((o) => o.userId === userId);
  res.status(200).json(userOrders);
});

app.listen(5000, () => {
  console.log("Server is running on http://localhost:5000");
});
