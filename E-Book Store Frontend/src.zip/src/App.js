import React, { useEffect, useState } from "react";
import "./index.css";
import Pagination from "./Pagination";

function App() {
  const [books, setBooks] = useState([]);
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState("");
  const [category, setCategory] = useState("");
  const [editId, setEditId] = useState(null);
  const [editTitle, setEditTitle] = useState("");
  const [editAuthor, setEditAuthor] = useState("");
  const [editPrice, setEditPrice] = useState("");
  const [editImage, setEditImage] = useState("");
  const [editCategory, setEditCategory] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOption, setSortOption] = useState("none");
  const [filterCategory, setFilterCategory] = useState("all");
  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem("cart");
    return saved ? JSON.parse(saved) : [];
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [toast, setToast] = useState(null);
  const [user, setUser] = useState(null);
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [registerUsername, setRegisterUsername] = useState("");
  const [registerEmail, setRegisterEmail] = useState("");
  const [registerPassword, setRegisterPassword] = useState("");
  const [paymentName, setPaymentName] = useState("");
  const [paymentEmail, setPaymentEmail] = useState("");
  const [paymentAddress, setPaymentAddress] = useState("");
  const [showPayment, setShowPayment] = useState(false);
  const [orders, setOrders] = useState([]);
  const booksPerPage = 8;

  useEffect(() => {
    fetch("http://localhost:5000/books")
      .then((res) => res.json())
      .then((data) => setBooks(data))
      .catch((err) => console.error(err));
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add("dark-mode");
    } else {
      document.body.classList.remove("dark-mode");
    }
  }, [isDarkMode]);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  useEffect(() => {
    if (user) {
      fetch(`http://localhost:5000/orders/${user.id}`)
        .then((res) => res.json())
        .then((data) => setOrders(data))
        .catch((err) => console.error(err));
    }
  }, [user]);

  const showToast = (message) => {
    setToast(message);
  };

  const handleAddBook = (e) => {
    e.preventDefault();
    if (!title || !author || !price || !category)
      return alert("Fill all fields");
    const newBook = { title, author, price: Number(price), image, category };

    fetch("http://localhost:5000/books", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newBook),
    })
      .then((res) => res.json())
      .then((data) => {
        setBooks([...books, data]);
        setTitle("");
        setAuthor("");
        setPrice("");
        setImage("");
        setCategory("");
        showToast("Book added successfully!");
      })
      .catch(() => alert("Failed to add book"));
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this book?")) {
      fetch(`http://localhost:5000/books/${id}`, { method: "DELETE" })
        .then((res) => {
          if (res.ok) {
            setBooks(books.filter((b) => b.id !== id));
            setCart(cart.filter((item) => item.book.id !== id));
            showToast("Book deleted successfully!");
          }
        })
        .catch(() => alert("Delete failed"));
    }
  };

  const handleEditClick = (book) => {
    setEditId(book.id);
    setEditTitle(book.title);
    setEditAuthor(book.author);
    setEditPrice(book.price);
    setEditImage(book.image || "");
    setEditCategory(book.category);
  };

  const handleEditSave = (id) => {
    if (!editTitle || !editAuthor || !editPrice || !editCategory)
      return alert("Fill all fields");
    const updatedBook = {
      title: editTitle,
      author: editAuthor,
      price: Number(editPrice),
      image: editImage,
      category: editCategory,
    };

    fetch(`http://localhost:5000/books/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedBook),
    })
      .then((res) => res.json())
      .then((data) => {
        setBooks(books.map((b) => (b.id === id ? data : b)));
        setEditId(null);
        showToast("Book updated successfully!");
      })
      .catch(() => alert("Failed to edit"));
  };

  const handleRatingSubmit = (bookId, stars, comment) => {
    if (!stars || !comment)
      return alert("Please provide both rating and comment");
    fetch(`http://localhost:5000/books/${bookId}/ratings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ stars: Number(stars), comment }),
    })
      .then((res) => res.json())
      .then((data) => {
        setBooks(
          books.map((b) =>
            b.id === bookId ? { ...b, ratings: [...b.ratings, data] } : b
          )
        );
        showToast("Rating submitted successfully!");
      })
      .catch(() => alert("Failed to add rating"));
  };

  const toggleFavorite = (bookId) => {
    const book = books.find((b) => b.id === bookId);
    const newFavoriteStatus = !book.isFavorite;
    fetch(`http://localhost:5000/books/${bookId}/favorite`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isFavorite: newFavoriteStatus }),
    })
      .then((res) => res.json())
      .then((data) => {
        setBooks(books.map((b) => (b.id === bookId ? data : b)));
        showToast(
          newFavoriteStatus ? "Added to favorites!" : "Removed from favorites!"
        );
      })
      .catch(() => alert("Failed to update favorite"));
  };

  const addToCart = (book) => {
    const found = cart.find((item) => item.book.id === book.id);
    if (found) {
      setCart(
        cart.map((item) =>
          item.book.id === book.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
    } else {
      setCart([...cart, { book, quantity: 1 }]);
    }
    showToast("Added to cart!");
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((item) => item.book.id !== id));
    showToast("Removed from cart!");
  };

  const updateQuantity = (id, qty) => {
    if (qty < 1) return;
    setCart(
      cart.map((item) =>
        item.book.id === id ? { ...item, quantity: qty } : item
      )
    );
  };

  const handleLogin = (e) => {
    e.preventDefault();
    fetch("http://localhost:5000/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: loginEmail, password: loginPassword }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.token) {
          setUser(data.user);
          localStorage.setItem("user", JSON.stringify(data.user));
          localStorage.setItem("token", data.token);
          setShowLogin(false);
          setLoginEmail("");
          setLoginPassword("");
          showToast("Logged in successfully!");
        } else {
          alert(data.message);
        }
      })
      .catch(() => alert("Login failed"));
  };

  const handleRegister = (e) => {
    e.preventDefault();
    fetch("http://localhost:5000/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: registerUsername,
        email: registerEmail,
        password: registerPassword,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.token) {
          setUser(data.user);
          localStorage.setItem("user", JSON.stringify(data.user));
          localStorage.setItem("token", data.token);
          setShowRegister(false);
          setRegisterUsername("");
          setRegisterEmail("");
          setRegisterPassword("");
          showToast("Registered successfully!");
        } else {
          alert(data.message);
        }
      })
      .catch(() => alert("Registration failed"));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    setCart([]);
    setOrders([]);
    showToast("Logged out successfully!");
  };

  const shareBook = (book) => {
    const shareData = {
      title: book.title,
      text: `Check out this book: ${book.title} by ${book.author}`,
      url: window.location.href,
    };
    if (navigator.share) {
      navigator
        .share(shareData)
        .then(() => showToast("Book shared successfully!"))
        .catch(() => alert("Failed to share book"));
    } else {
      alert("Share feature not supported in this browser");
    }
  };

  const handlePayment = (e) => {
    e.preventDefault();
    if (!paymentName || !paymentEmail || !paymentAddress) {
      return alert("Please fill all payment fields");
    }
    if (!user) {
      return alert("Please login to proceed with payment");
    }
    fetch("http://localhost:5000/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: user.id,
        items: cart,
        name: paymentName,
        email: paymentEmail,
        address: paymentAddress,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        setOrders([...orders, data]);
        setCart([]);
        setPaymentName("");
        setPaymentEmail("");
        setPaymentAddress("");
        setShowPayment(false);
        showToast("Order placed successfully!");
      })
      .catch(() => alert("Payment failed"));
  };

  const filteredBooks = books.filter(
    (b) =>
      (b.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        b.author.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (filterCategory === "all" || b.category === filterCategory)
  );

  const sortedBooks = [...filteredBooks].sort((a, b) => {
    switch (sortOption) {
      case "title-asc":
        return a.title.localeCompare(b.title);
      case "title-desc":
        return b.title.localeCompare(a.title);
      case "price-asc":
        return a.price - b.price;
      case "price-desc":
        return b.price - a.price;
      default:
        return 0;
    }
  });

  const indexOfLastBook = currentPage * booksPerPage;
  const indexOfFirstBook = indexOfLastBook - booksPerPage;
  const currentBooks = sortedBooks.slice(indexOfFirstBook, indexOfLastBook);

  const favoriteBooks = books.filter((b) => b.isFavorite);

  const totalPrice = cart.reduce(
    (sum, item) => sum + item.book.price * item.quantity,
    0
  );

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const categories = [
    "all",
    ...new Set(books.map((b) => b.category).filter(Boolean)),
  ];

  return (
    <div>
      <nav className="navbar">
        <div className="nav-container">
          <a href="/" className="logo">
            <span>E-Book Store</span>
          </a>
          <div className="nav-links">
            <a href="/">Home</a>
            <a href="/">Books</a>
            <a href="/">Categories</a>
            <a href="/" className="cart-icon">
              Cart
              {cartCount > 0 && <span className="cart-count">{cartCount}</span>}
            </a>
            {user ? (
              <>
                <span>Welcome, {user.username}</span>
                <button onClick={handleLogout} className="auth-btn">
                  Logout
                </button>
              </>
            ) : (
              <>
                <button onClick={() => setShowLogin(true)} className="auth-btn">
                  Login
                </button>
                <button
                  onClick={() => setShowRegister(true)}
                  className="auth-btn"
                >
                  Register
                </button>
              </>
            )}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="dark-mode-toggle"
            >
              {isDarkMode ? "☀️" : "🌙"}
            </button>
          </div>
        </div>
      </nav>

      {showLogin && (
        <div className="auth-modal">
          <div className="auth-content">
            <div className="auth-image">
              <img
                src="https://images.unsplash.com/photo-1512820790803-83ca734da794"
                alt="Books"
              />
            </div>
            <div className="auth-form">
              <h2>Login</h2>
              <form onSubmit={handleLogin}>
                <input
                  type="email"
                  placeholder="Email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                />
                <input
                  type="password"
                  placeholder="Password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                />
                <button type="submit">Login</button>
                <button type="button" onClick={() => setShowLogin(false)}>
                  Cancel
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {showRegister && (
        <div className="auth-modal">
          <div className="auth-content">
            <div className="auth-image">
              <img
                src="https://images.unsplash.com/photo-1543002588-bfa74002ed7e"
                alt="Books"
              />
            </div>
            <div className="auth-form">
              <h2>Register</h2>
              <form onSubmit={handleRegister}>
                <input
                  type="text"
                  placeholder="Username"
                  value={registerUsername}
                  onChange={(e) => setRegisterUsername(e.target.value)}
                />
                <input
                  type="email"
                  placeholder="Email"
                  value={registerEmail}
                  onChange={(e) => setRegisterEmail(e.target.value)}
                />
                <input
                  type="password"
                  placeholder="Password"
                  value={registerPassword}
                  onChange={(e) => setRegisterPassword(e.target.value)}
                />
                <button type="submit">Register</button>
                <button type="button" onClick={() => setShowRegister(false)}>
                  Cancel
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      <div className="container">
        <h1>Discover Your Next Read</h1>

        <div className="filters">
          <input
            type="text"
            placeholder="Search by title or author..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value)}
          >
            <option value="none">Sort by</option>
            <option value="title-asc">Title (A-Z)</option>
            <option value="title-desc">Title (Z-A)</option>
            <option value="price-asc">Price (Low to High)</option>
            <option value="price-desc">Price (High to Low)</option>
          </select>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat === "all" ? "All Categories" : cat}
              </option>
            ))}
          </select>
        </div>

        <form onSubmit={handleAddBook} className="add-form">
          <input
            type="text"
            placeholder="Book Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <input
            type="text"
            placeholder="Author Name"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
          />
          <input
            type="number"
            placeholder="Price"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            min="0"
            step="0.01"
          />
          <input
            type="text"
            placeholder="Image URL"
            value={image}
            onChange={(e) => setImage(e.target.value)}
          />
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">Select Category</option>
            <option value="Programming">Programming</option>
            <option value="Design">Design</option>
            <option value="Architecture">Architecture</option>
            <option value="Management">Management</option>
          </select>
          <button type="submit">Add Book</button>
        </form>

        <div className="books-grid">
          {currentBooks.map((book) => (
            <div key={book.id} className="book-card">
              {editId === book.id ? (
                <>
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    placeholder="Title"
                  />
                  <input
                    type="text"
                    value={editAuthor}
                    onChange={(e) => setEditAuthor(e.target.value)}
                    placeholder="Author"
                  />
                  <input
                    type="number"
                    value={editPrice}
                    onChange={(e) => setEditPrice(e.target.value)}
                    placeholder="Price"
                    min="0"
                    step="0.01"
                  />
                  <input
                    type="text"
                    value={editImage}
                    onChange={(e) => setEditImage(e.target.value)}
                    placeholder="Image URL"
                  />
                  <select
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value)}
                  >
                    <option value="">Select Category</option>
                    <option value="Programming">Programming</option>
                    <option value="Design">Design</option>
                    <option value="Architecture">Architecture</option>
                    <option value="Management">Management</option>
                  </select>
                  <div className="buttons">
                    <button
                      onClick={() => handleEditSave(book.id)}
                      className="edit-btn"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setEditId(null)}
                      className="delete-btn"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              ) : (
                <>
                  {book.image ? (
                    <img
                      src={book.image}
                      alt={book.title}
                      className="book-image"
                      onClick={() => setSelectedImage(book.image)}
                      onError={(e) =>
                        (e.target.src =
                          "https://images.unsplash.com/photo-1543002588-bfa74002ed7e")
                      }
                    />
                  ) : (
                    <div
                      className="book-image"
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "var(--gray)",
                      }}
                    >
                      No Image
                    </div>
                  )}
                  <h3>{book.title}</h3>
                  <p>Author: {book.author}</p>
                  <p>Category: {book.category}</p>
                  <p className="price">Price: ${book.price.toFixed(2)}</p>
                  <div className="ratings">
                    <p>
                      Average Rating:{" "}
                      {book.ratings.length
                        ? (
                            book.ratings.reduce((sum, r) => sum + r.stars, 0) /
                            book.ratings.length
                          ).toFixed(1)
                        : "No ratings"}
                    </p>
                    {book.ratings.map((rating) => (
                      <div key={rating.id} className="rating-item">
                        <p>Stars: {rating.stars}</p>
                        <p>{rating.comment}</p>
                      </div>
                    ))}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        const stars = e.target.stars.value;
                        const comment = e.target.comment.value;
                        handleRatingSubmit(book.id, stars, comment);
                        e.target.reset();
                      }}
                      className="rating-form"
                    >
                      <select name="stars">
                        <option value="1">1 Star</option>
                        <option value="2">2 Stars</option>
                        <option value="3">3 Stars</option>
                        <option value="4">4 Stars</option>
                        <option value="5">5 Stars</option>
                      </select>
                      <input
                        type="text"
                        name="comment"
                        placeholder="Add a comment"
                      />
                      <button type="submit">Submit Rating</button>
                    </form>
                  </div>
                  <div className="buttons">
                    <button
                      onClick={() => handleEditClick(book)}
                      className="edit-btn"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(book.id)}
                      className="delete-btn"
                    >
                      Delete
                    </button>
                    <button
                      onClick={() => addToCart(book)}
                      className="cart-btn"
                    >
                      Add to Cart
                    </button>
                    <button
                      onClick={() => toggleFavorite(book.id)}
                      className="favorite-btn"
                    >
                      {book.isFavorite ? "❤️" : "♡"}
                    </button>
                    <button
                      onClick={() => shareBook(book)}
                      className="share-btn"
                    >
                      Share
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>

        <Pagination
          totalBooks={sortedBooks.length}
          booksPerPage={booksPerPage}
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
        />

        <div className="favorites-section">
          <h2 className="section-title">Your Favorites</h2>
          {favoriteBooks.length === 0 ? (
            <div className="empty-favorites">
              <p>No favorite books yet</p>
            </div>
          ) : (
            <div className="books-grid">
              {favoriteBooks.map((book) => (
                <div key={book.id} className="book-card">
                  {book.image ? (
                    <img
                      src={book.image}
                      alt={book.title}
                      className="book-image"
                      onClick={() => setSelectedImage(book.image)}
                      onError={(e) =>
                        (e.target.src =
                          "https://images.unsplash.com/photo-1543002588-bfa74002ed7e")
                      }
                    />
                  ) : (
                    <div
                      className="book-image"
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "var(--gray)",
                      }}
                    >
                      No Image
                    </div>
                  )}
                  <h3>{book.title}</h3>
                  <p>Author: {book.author}</p>
                  <p>Category: {book.category}</p>
                  <p className="price">Price: ${book.price.toFixed(2)}</p>
                  <div className="buttons">
                    <button
                      onClick={() => addToCart(book)}
                      className="cart-btn"
                    >
                      Add to Cart
                    </button>
                    <button
                      onClick={() => toggleFavorite(book.id)}
                      className="favorite-btn"
                    >
                      {book.isFavorite ? "❤️" : "♡"}
                    </button>
                    <button
                      onClick={() => shareBook(book)}
                      className="share-btn"
                    >
                      Share
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="cart-section">
          <h2 className="section-title">Shopping Cart</h2>
          {cart.length === 0 ? (
            <div className="empty-cart">
              <p>Your cart is empty</p>
            </div>
          ) : (
            <>
              {cart.map(({ book, quantity }) => (
                <div key={book.id} className="cart-card">
                  <h4>{book.title}</h4>
                  <p>Author: {book.author}</p>
                  <p>Price: ${book.price.toFixed(2)}</p>
                  <label>
                    Quantity:
                    <input
                      type="number"
                      min={1}
                      value={quantity}
                      onChange={(e) =>
                        updateQuantity(book.id, Number(e.target.value))
                      }
                    />
                  </label>
                  <button
                    onClick={() => removeFromCart(book.id)}
                    className="delete-btn"
                  >
                    Remove
                  </button>
                </div>
              ))}
              <div className="total-price">Total: ${totalPrice.toFixed(2)}</div>
              <button
                onClick={() => setShowPayment(true)}
                className="checkout-btn"
              >
                Proceed to Checkout
              </button>
            </>
          )}
        </div>

        {showPayment && (
          <div className="payment-modal">
            <div className="payment-content">
              <h2>Checkout</h2>
              <form onSubmit={handlePayment}>
                <input
                  type="text"
                  placeholder="Full Name"
                  value={paymentName}
                  onChange={(e) => setPaymentName(e.target.value)}
                />
                <input
                  type="email"
                  placeholder="Email"
                  value={paymentEmail}
                  onChange={(e) => setPaymentEmail(e.target.value)}
                />
                <input
                  type="text"
                  placeholder="Address"
                  value={paymentAddress}
                  onChange={(e) => setPaymentAddress(e.target.value)}
                />
                <button type="submit">Confirm Payment</button>
                <button type="button" onClick={() => setShowPayment(false)}>
                  Cancel
                </button>
              </form>
            </div>
          </div>
        )}

        {user && (
          <div className="orders-section">
            <h2 className="section-title">Your Orders</h2>
            {orders.length === 0 ? (
              <div className="empty-orders">
                <p>No orders yet</p>
              </div>
            ) : (
              <div className="orders-grid">
                {orders.map((order) => (
                  <div key={order.id} className="order-card">
                    <p>Order ID: {order.id}</p>
                    <p>Date: {new Date(order.date).toLocaleDateString()}</p>
                    <p>Total: ${order.total.toFixed(2)}</p>
                    <p>Name: {order.name}</p>
                    <p>Email: {order.email}</p>
                    <p>Address: {order.address}</p>
                    <h4>Items:</h4>
                    {order.items.map(({ book, quantity }) => (
                      <div key={book.id} className="order-item">
                        <p>
                          {book.title} - ${book.price.toFixed(2)} x {quantity}
                        </p>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {selectedImage && (
        <div className="lightbox" onClick={() => setSelectedImage(null)}>
          <img src={selectedImage} alt="Enlarged book" />
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}

export default App;
